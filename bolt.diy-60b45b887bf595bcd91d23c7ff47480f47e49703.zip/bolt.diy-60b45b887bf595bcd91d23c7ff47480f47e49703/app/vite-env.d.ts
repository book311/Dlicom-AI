declare const __COMMIT_HASH: string;
declare const __APP_VERSION: string;
